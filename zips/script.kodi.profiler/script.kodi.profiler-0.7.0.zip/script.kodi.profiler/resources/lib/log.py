import xbmc
def info(msg): xbmc.log(f"[Profiler] {msg}", xbmc.LOGINFO)
def err(msg): xbmc.log(f"[Profiler] {msg}", xbmc.LOGERROR)
